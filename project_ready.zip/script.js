function showMessage() {
  document.getElementById("msg").innerText = "تم تشغيل الجافاسكريبت بنجاح! ✔";
}